# TeamPulse: Team Leave & Bandwidth Management Web Portal

A full-fledged, real-time SaaS web application for team attendance tracking, capacity planning, and automated manager escalation triggers designed for 100+ team members.

---

## 🌐 Live Website

The website is currently **ONLINE and RUNNING** at:
👉 **[http://localhost:5000](http://localhost:5000)**

You can also directly open [`index.html`](file:///C:/Users/Dell/.gemini/antigravity/scratch/team-bandwidth-tracker/index.html) in any web browser without needing any web server.

---

## 🖥️ Website Views & Architecture

1. **🗓️ Attendance & Bandwidth Matrix**:
   - 100 team members with sticky left columns (`Member Name`, `Project Name`, `Backup Person`, `Reason for Leave`).
   - Dynamic date columns with day-of-week, dates, and live bandwidth % badges.
   - Real-time bottom sticky calculation rows for Working, Half-Day, Planned Leaves, and **Bandwidth Capacity %**.
   - Automatic `<40%` red alert banner and trigger escalation.

2. **📊 Bandwidth Analytics**:
   - Interactive daily bandwidth bar graphs highlighting dates that breach the 40% threshold.
   - Project-by-project capacity health breakdown.

3. **🚨 Manager Escalation Center**:
   - Incident feed showing all critical shortage dates.
   - Absent roster with backup cross-checks (flags `⚠️ (Also Absent!)` if a backup colleague is taking leave on the same day).
   - One-click "Copy / Dispatch Escalation Email" button for leads.

4. **👥 Team Directory (100 Members)**:
   - Searchable card directory showing employee profiles, project assignments, backup peers, and today's status badge.

5. **📝 Self-Service Leave Form**:
   - Allows any team member to pick their name or register a new name, select their status (`Working`, `Planned Leave`, `Half day`, `Not Applicable`), assign a backup, and specify reason & project.

---

## ⚡ Starting / Stopping the Web Server

- To start the server manually anytime:
  ```powershell
  cd C:\Users\Dell\.gemini\antigravity\scratch\team-bandwidth-tracker
  python server.py
  ```
- Or simply double-click [`index.html`](file:///C:/Users/Dell/.gemini/antigravity/scratch/team-bandwidth-tracker/index.html) to run standalone in any browser!
